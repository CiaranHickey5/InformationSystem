import java.util.Scanner;
import java.util.List;

public class Main {
        Scanner input = new Scanner(System.in);
        public static AuctionLot headLot;
        public static AuctionBidder headBidder;

        public static void main(String[] args) throws Exception {
                Main m = new Main();
                BidderHashTable b = new BidderHashTable(17);
                m.runMenu();
        }

        private int mainMenu() {
                System.out.println("Auction Menu");
                System.out.println("-------------------------------------");
                System.out.println(" 1) Add an auction lot");
                System.out.println(" 2) Add an auction bidder");
                System.out.println(" 3) Add an auction bid");
                System.out.println("-------------------------------------");
                System.out.println(" 4) Display all auction lots");
                System.out.println(" 5) Display all auction bidders");
                System.out.println(" 6) Display all top auction bids");
                System.out.println("-------------------------------------");
                System.out.println(" 7) Sell an auction lot for the current top bid");
                System.out.println(" 8) Withdraw an auction lot from auction");
                System.out.println(" 9) Withdraw an auction bid from auction");
                System.out.println("-------------------------------------");
                System.out.println(" 10) Edit an auction lot");
                System.out.println(" 11) Edit an auction bid");
                System.out.println(" 12) Display all auction bids in the system");
                System.out.println(" 13) Display all auction bids in a specific auction lot");
                System.out.println(" 0) Exit");
                System.out.print("Enter option: ");
                int option = input.nextInt();
                return option;
        }

        private void runMenu() throws Exception {
                int option = mainMenu();
                while (option != 0) {
                        switch (option) {
                                case 1:
                                        addAuctionLot();
                                        break;
                                case 2:
                                        addAuctionBidder();
                                        break;
                                case 3:
                                        addAuctionBid();
                                        break;
                                case 4:
                                        printAuctionLot();
                                        break;
                                case 5:
                                        printAuctionBidder();
                                        break;
                                case 6:
                                        printAuctionBid();
                                        break;
                                case 7:
                                        sellAuctionLot();
                                        break;
                                case 8:
                                        withdrawLot();
                                        break;
                                case 9:
                                        withdrawBid();
                                        break;
                                case 10:
                                        editLot();
                                        break;
                                case 11:
                                        editBid();
                                        break;
                                default:
                                        System.out.println("Invalid input entered");
                        }
                        System.out.println("\nPress any key to continue...");
                        input.nextLine();
                        input.nextLine();
                        option = mainMenu();
                }
                System.out.println("Exiting... bye");
                System.exit(0);
        }

        public void addAuctionLot() {
                input.nextLine();
                System.out.println("Enter the auction lot name");
                String name = input.nextLine();
                System.out.println("Enter the auction lot description");
                String description = input.nextLine();
                System.out.println("Enter the auction lot type");
                String type = input.nextLine();
                System.out.println("Enter the auction lot's year of origin");
                int year = input.nextInt();
                System.out.println("Enter the asking price of the auction lot");
                double askingPrice = input.nextDouble();
                input.nextLine();
                System.out.println("Enter the url of an image");
                String image = input.nextLine();
                AuctionLot auctionLot = new AuctionLot(name, description, type, year, askingPrice, image);
                auctionLot.nextLot = headLot;
                headLot = auctionLot;
        }

//        public static void insertionSortLots(AuctionLot lots){
//                for(int e=1; e<lots.size();e++){
//                        AuctionLot elem = lots.get(e);
//
//                        for(int i=e; i>=1 && lots.getIt(i-1).compareTo(elem)>0;i--){
//                                lots.set(i,lots.getIt(i-1));
//                                lots.set(i,(elem));
//                        }
//                }
//        }

        public void addAuctionBidder() {
                input.nextLine();
                System.out.println("Enter your full name");
                String name = input.nextLine();
                System.out.println("Enter your address");
                String address = input.nextLine();
                System.out.println("Enter your telephone number");
                String telephone = input.nextLine();
                System.out.println("Enter your email");
                String email = input.nextLine();

                AuctionBidder auctionBidder = new AuctionBidder(name, address, telephone, email);
                auctionBidder.nextBidder = headBidder;
                headBidder = auctionBidder;
        }

        public void addAuctionBid() {
                input.nextLine();
                printAuctionBidder();
                System.out.println("Enter your name");
                String bidderName = input.nextLine();
                AuctionBidder foundBidder = findBidder(bidderName);

                if (foundBidder != null) {
                        printAuctionLot();
                        System.out.println("Enter the name of the auction lot");
                        String lotName = input.nextLine();
                        AuctionLot foundLot = findLot(lotName);

                        if (foundLot != null) {
                                input.nextLine();
                                System.out.println("Enter the bid amount");
                                double bidAmount = input.nextDouble();
                                input.nextLine();
                                System.out.println("Enter the time of the bid");
                                String time = input.nextLine();
                                AuctionBid auctionBid = new AuctionBid(bidAmount, time);

                                //When there isn't already a bid and the bid is greater or equal to the asking price
                                if (foundLot.headBid == null && bidAmount >= foundLot.getAskingPrice()) {
                                        foundLot.headBid = auctionBid;
                                }
                                //When there isn't already a bid and the bid is less than the asking price
                                else if (foundLot.headBid == null) {
                                        System.out.println("Bid must be greater than or equal to the asking price of " + foundLot.getAskingPrice());
                                }
                                //When there is an existing bid
                                else if (foundLot.headBid != null) {
                                        //The bid is greater than the existing bid, so it becomes the head bid
                                        if (bidAmount > foundLot.headBid.getBidAmount()) {
                                                //The head bid becomes the 2nd bid
                                                foundLot.headBid = foundLot.headBid.nextBid;
                                                //The entered bid becomes the head bid
                                                foundLot.headBid = auctionBid;
                                                System.out.println("The new head bid is " + auctionBid.getBidAmount());
                                        }
                                        //The bid isn't higher than the current bid
                                        else {
                                                System.out.println("Bid amount is not greater than the current bid of " + foundLot.headBid.getBidAmount());
                                        }
                                }
                        } else {
                                System.out.println("Invalid auction lot entered");
                        }
                } else {
                        System.out.println("Invalid auction bidder entered");
                }
        }


        public void printAuctionLot() {
                input.nextLine();
                System.out.println("Here is a list of all auction lots: \n");
                AuctionLot currentLot = headLot;
                while (currentLot != null) {
                        System.out.println(currentLot);
                        currentLot = currentLot.nextLot;
                }
        }

        public void printAuctionBidder() {
                input.nextLine();
                System.out.println("Here is a list of all auction bidders: \n");
                AuctionBidder currentBidder = headBidder;
                while (currentBidder != null) {
                        System.out.println(currentBidder);
                        currentBidder = currentBidder.nextBidder;
                }
        }

        public void printAuctionBid(){
                input.nextLine();
                System.out.println("Enter the number for the type of bid menu you would like to be displayed");
                System.out.println("1) All top bids for each auction lot");
                System.out.println("2) Every bid in the system");
                System.out.println("3) Every bid in a specific lot");
                int number = input.nextInt();
                switch (number){
                        case 1:
                                printTopAuctionBids();
                                break;
                        case 2:
                                printAllAuctionBids();
                                break;
                        case 3:
                                printLotAuctionBids();
                                break;
                        default:
                                System.out.println("Invalid input entered");
                }
        }

        public void printTopAuctionBids() {
                input.nextLine();
                System.out.println("Here is a list of all the current top bids on all auction lots");
                AuctionLot currentLot = headLot;
                while (currentLot != null) {
                        //If the auction lot doesn't have a bid, display that to the console.
                        if(currentLot.headBid==null){
                                System.out.println("Auction lot " + currentLot.getName() + " does not have a bid yet");
                        }
                        //Otherwise, display the bid to the console.
                        else {
                                System.out.println("The current top bid of auction lot "+currentLot.getName()+" is "
                                        +currentLot.headBid.getBidAmount()+" and was placed at "+currentLot.headBid.getTimeOfBid());
                        }
                        currentLot=currentLot.nextLot;
                }
        }

        public void printAllAuctionBids(){
                input.nextLine();
                System.out.println("Here is a list of all the current bids on all auction lots");
                AuctionLot currentLot = headLot;
                while (currentLot != null) {
                        AuctionBid currentBid = currentLot.headBid;
                        while(currentBid.nextBid!=null){
                                System.out.println("A bid of "+ currentBid.getBidAmount()+" in auction lot "
                                        + currentLot.getName() + " at a time of "+currentBid.getTimeOfBid());
                                currentBid = currentBid.nextBid;
                        }
                        currentLot=currentLot.nextLot;
                }
        }

        public void printLotAuctionBids(){
                input.nextLine();
                System.out.println("Enter the name of the auction lot you wish to see all the bids of");
                String name=input.nextLine();
                AuctionLot foundLot = findLot(name);
                if(foundLot!=null){
                        AuctionBid currentBid = foundLot.headBid;
                        while(currentBid!=null){
                                System.out.println("A bid of "+ currentBid.getBidAmount()+ "was placed at a time of "+currentBid.getTimeOfBid());
                        }
                }
                else{
                        System.out.println("Invalid auction lot name entered");
                }
        }

        public AuctionLot findLot(String name) {
                AuctionLot currentLot = headLot;
                while (currentLot != null) {
                        if (currentLot.getName().equals(name)) {
                                return currentLot;
                        }
                        currentLot = currentLot.nextLot;
                }
                return null;
        }

        public AuctionBidder findBidder(String name) {
                AuctionBidder currentBiider = headBidder;
                while (currentBiider != null) {
                        if (currentBiider.getName().equals(name)) {
                                return currentBiider;
                        }
                        currentBiider = currentBiider.nextBidder;
                }
                return null;
        }

        public void sellAuctionLot() {
                input.nextLine();
                printAuctionLot();
                System.out.println("Enter the name of the auction lot you wish to sell");
                String name = input.nextLine();
                AuctionLot foundLot = findLot(name);
                if (foundLot != null) {
                        input.nextLine();
                        AuctionLot currentLot = headLot;
                        while (currentLot != null && currentLot.nextLot!=foundLot) {
                                //Making the headLot null when the headLot is the only element in the linkedList
                                if (currentLot == headLot && currentLot.nextLot == null) {
                                        headLot = null;
                                }
                                //Making the headLot the nextLot when there is a nextLot
                                else if (currentLot == headLot && currentLot.nextLot != null) {
                                        headLot = currentLot.nextLot;
                                }
                                //Making the nextLot, the nextLot's nextLot. Deleting the lot in the middle
                                else if (currentLot != null && currentLot.nextLot != null) {
                                        while (currentLot.nextLot != foundLot) {
                                                //If the foundLot has a lot after it, it becomes null
                                                if (currentLot.nextLot.nextLot != null) {
                                                        currentLot.nextLot = currentLot.nextLot.nextLot;
                                                }
                                                //If the foundLot doesn't have a lot after it, it is set to null
                                                else if (currentLot.nextLot.nextLot == null) {
                                                        currentLot.nextLot = null;
                                                }
                                                currentLot = currentLot.nextLot;
                                        }
                                }
                                currentLot = currentLot.nextLot;
                        }
                        System.out.println("Auction lot sold for " + foundLot.headBid.getBidAmount());
                }
                else {
                        System.out.println("Auction lot not found");
                }
        }


        public void withdrawLot() {
                input.nextLine();
                printAuctionLot();
                System.out.println("Enter the name of the auction lot you wish to withdraw from auction");
                String name = input.nextLine();
                AuctionLot foundLot = findLot(name);
                if (foundLot != null) {
                        input.nextLine();
                        AuctionLot currentLot = headLot;
                        while (currentLot != null && currentLot.nextLot!=foundLot) {
                                //Making the headLot null when the headLot is the only element in the linkedList
                                if (currentLot == headLot && currentLot.nextLot == null) {
                                        headLot = null;
                                }
                                //Making the headLot the nextLot when there is a nextLot
                                else if (currentLot == headLot && currentLot.nextLot != null) {
                                        headLot = currentLot.nextLot;
                                }
                                //Making the nextLot, the nextLot's nextLot. Deleting the lot in the middle
                                else if (currentLot != null && currentLot.nextLot != null) {
                                        while (currentLot.nextLot != foundLot) {
                                                //If the foundLot has a lot after it, it becomes null
                                                if (currentLot.nextLot.nextLot != null) {
                                                        currentLot.nextLot = currentLot.nextLot.nextLot;
                                                }
                                                //If the foundLot doesn't have a lot after it, it is set to null
                                                else if (currentLot.nextLot.nextLot == null) {
                                                        currentLot.nextLot = null;
                                                }
                                                currentLot = currentLot.nextLot;
                                        }
                                }
                                currentLot = currentLot.nextLot;
                        }
                }
                else {
                        System.out.println("Auction lot not found");
                }
        }

        public void withdrawBid() {
                input.nextLine();
                System.out.println("Please enter the name of the auction lot you wish to remove the bid from");
                String name = input.nextLine();
                AuctionLot foundLot = findLot(name);
                if(foundLot!=null){
                        if(foundLot.headBid.nextBid!=null){
                                foundLot.headBid= foundLot.headBid.nextBid;
                        }
                        else{
                                foundLot.headBid=null;
                        }
                }
                else{
                        System.out.println("Invalid auction lot entered");
                }
        }

        public void editLot() {
                input.nextLine();
                printAuctionLot();
                System.out.println("Enter the name of the auction lot that you wish to edit");
                String name = input.nextLine();
                AuctionLot foundLot = findLot(name);
                if (foundLot != null) {
                        System.out.println("1)Name, 2)Description, 3)Type, 4)Year, 5)Asking Price, 6)Image");
                        System.out.println("Please enter the number for the corresponding field you wish to edit");
                        int choice = input.nextInt();
                        if (choice == 1) {
                                input.nextLine();
                                System.out.println("Enter the new name of the auction lot");
                                String newName = input.nextLine();
                                foundLot.setName(newName);
                        } else if (choice == 2) {
                                input.nextLine();
                                System.out.println("Enter the new description of the auction lot");
                                String description = input.nextLine();
                                foundLot.setDescription(description);
                        } else if (choice == 3) {
                                input.nextLine();
                                System.out.println("Please enter the new type of the auction lot");
                                String type = input.nextLine();
                                foundLot.setType(type);
                        } else if (choice == 4) {
                                input.nextLine();
                                System.out.println("Please enter the new year of origin of the auction lot");
                                int year = input.nextInt();
                                foundLot.setYear(year);
                        } else if (choice == 5) {
                                input.nextLine();
                                System.out.println("Please enter the new asking price of the auction lot");
                                double askingPrice = input.nextDouble();
                                foundLot.setAskingPrice(askingPrice);
                        } else if (choice == 6) {
                                input.nextLine();
                                System.out.println("Please enter the new image url of the auction lot");
                                String image = input.nextLine();
                                foundLot.setImage(image);
                        } else {
                                System.out.println("Invalid input entered");
                        }
                } else {
                        System.out.println("Invalid auction lot entered");
                }
        }

        public void editBid() {
                input.nextLine();
                printAuctionLot();
                System.out.println("Please enter the name of the auction lot that the bid belongs to");
                String lotName = input.nextLine();
                AuctionLot foundLot = findLot(lotName);
                if (foundLot != null) {
                        System.out.println("1)Bid amount, 2)Time of bid");
                        System.out.println("Please enter the number for the corresponding field that you wish to edit");
                        int choice = input.nextInt();
                        if (choice == 1) {
                                input.nextLine();
                                System.out.println("Please enter the new bid amount");
                                double newBid = input.nextDouble();
                                foundLot.headBid.setBidAmount(newBid);
                        } else if (choice == 2) {
                                input.nextLine();
                                System.out.println("Please enter the new time of the bid");
                                String time = input.nextLine();
                                foundLot.headBid.setTimeOfBid(time);
                        } else {
                                System.out.println("Invalid input entered");
                        }
                } else {
                        System.out.println("Auction lot not found");
                }
        }

//        public void save(){
//                XStream xStream = new XStream(new DomDriver());
//
//                ObjectOutputStream out = xStream.createObjectOutputStream(new FileWriter("auction.xml"));
//                out.writeObject(headLot);
//                out.writeObject(headBidder);
//                out.close();
//        }
//
//        public void load(){
//                XStream xStream = new XStream(new DomDriver());
//                xStream.addPermission(AnyTypePermission.ANY);
//                ObjectInputStream is = xStream.createObjectInputStream(new FileReader("auction.xml"));
//                headLot=(AuctionLot)is.readObject();
//                headBidder=(AuctionBidder) is.readObject();
//        }
}
