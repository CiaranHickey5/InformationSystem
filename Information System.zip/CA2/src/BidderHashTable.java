import java.util.List;
import static java.util.Objects.hash;

public class BidderHashTable {
    public int[] bidderHashTable;

    public BidderHashTable(int size){
        bidderHashTable=new int [size];
        size=0;
    }

    public void add(int i){

    }
}
