import java.util.List;

public class AuctionLot implements Comparable<AuctionLot>{
    private String name,description,type,image,timeOfSale;
    private int year;
    private double askingPrice, finalPrice;
    public AuctionLot nextLot;
    public AuctionBid headBid;

    public AuctionLot(String name, String description, String type, int year, double askingPrice, String image){
        this.name=name;
        this.description=description;
        this.type=type;
        this.year=year;
        this.askingPrice=askingPrice;
        this.image=image;
    }

    public int size(){
        int count = 0;
        AuctionLot temp= Main.headLot;
        while(temp!=null){
            temp=temp.nextLot;
            count++;
        }
        return count;
    }

    //Get and set methods needed
    //...
    public String getName(){
        return name;
    }

    public void setName(String name){
        this.name=name;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getImage() {
        return image;
    }

    public void setImage(String image) {
        this.image = image;
    }

    public String getTimeOfSale() {
        return timeOfSale;
    }

    public void setTimeOfSale(String timeOfSale) {
        this.timeOfSale = timeOfSale;
    }

    public int getYear() {
        return year;
    }

    public void setYear(int year) {
        this.year = year;
    }

    public double getAskingPrice() {
        return askingPrice;
    }

    public void setAskingPrice(double askingPrice) {
        this.askingPrice = askingPrice;
    }

    public double getFinalPrice() {
        return finalPrice;
    }

    public void setFinalPrice(double finalPrice) {
        this.finalPrice = finalPrice;
    }

    @Override
    public String toString() {
        return name + ": " + '\'' +
                "description='" + description + '\'' +
                ", type='" + type + '\'' +
                ", image='" + image + '\'' +
                ", year=" + year +
                ", askingPrice=" + askingPrice;
    }

    public int compareTo(AuctionLot lot){
        return this.getName().compareTo(lot.getName());
    }
}
