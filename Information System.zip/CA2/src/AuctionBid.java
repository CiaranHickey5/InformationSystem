public class AuctionBid {
    private double bidAmount;
    private String timeOfBid;
    public AuctionBid nextBid;

    public AuctionBid(double bidAmount, String timeOfBid){
        if(bidAmount>this.bidAmount){
            this.bidAmount=bidAmount;
        }
        this.timeOfBid=timeOfBid;
    }

    public double getBidAmount(){
        return bidAmount;
    }

    public void setBidAmount(double bidAmount){
        this.bidAmount=bidAmount;
    }

    public String getTimeOfBid(){
        return timeOfBid;
    }

    public void setTimeOfBid(String timeOfBid){
        this.timeOfBid=timeOfBid;
    }

    @Override
    public String toString() {
        return "AuctionBid{" +
                "bidAmount=" + bidAmount +
                ", timeOfBid='" + timeOfBid + '\'' +
                '}';
    }
}
