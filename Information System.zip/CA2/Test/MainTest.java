import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class MainTest {

    @org.junit.jupiter.api.BeforeEach
        //Before creating any tests, a bidder is created.
    void setUp() {
        AuctionBidder auctionBidder=new AuctionBidder("Ciaran Hickey","Waterford, Ireland","0123456789","ciaranhickey@gmail.com");
        Main.headBidder=auctionBidder;
    }
    @Test
    public void getBidderName(){
        assertEquals("Ciaran Hickey",Main.headBidder.getName());
    }
    @Test
    public void setBidderName(){
        Main.headBidder.setName("Not Ciaran Hickey");
        assertEquals("Not Ciaran Hickey",Main.headBidder.getName());
    }
    @Test
    public void getBidderAddress(){
        assertEquals("Waterford, Ireland", Main.headBidder.getAddress());
    }
    @Test
    public void setBidderAddress(){
        Main.headBidder.setAddress("London, England");
        assertEquals("London, England", Main.headBidder.getAddress());
    }
    @Test
    public void getBidderTelephone(){
        assertEquals("0123456789",Main.headBidder.getTelephone());
    }
    @Test
    public void setBidderTelephone(){
        Main.headBidder.setTelephone("0987654321");
        assertEquals("0987654321",Main.headBidder.getTelephone());
    }
    @Test
    public void getBidderEmail(){
        assertEquals("ciaranhickey@gmail.com",Main.headBidder.getEmail());
    }
    @Test
    public void setBidderEmail(){
        Main.headBidder.setEmail("notmyemail@gmail.com");
        assertEquals("notmyemail@gmail.com",Main.headBidder.getEmail());
    }
}